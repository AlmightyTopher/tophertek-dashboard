"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function HomeRedirect() {
  const router = useRouter();

  useEffect(() => {
    router.push("/_/dashboard");
  }, [router]);

  return <p>Redirecting to dashboard...</p>;
}
